//
//  ViewController.swift
//  DecoderJSON
//
//  Created by King on 01/05/18.
//  Copyright © 2018 TripalA. All rights reserved.
//

import UIKit
struct info:Decodable {
    let id:Int
    let name:String
}

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    @IBOutlet weak var informationTable: UITableView!
    var nameArray:[String] = []
     var IDArray:[Int] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
            self.JSONCall()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
         return nameArray.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = informationTable.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        let IdNo:UIButton = cell.viewWithTag(1) as! UIButton
        let name:UILabel = cell.viewWithTag(2) as! UILabel
        name.text = nameArray[indexPath.row]
        IdNo.titleLabel?.text = "\(IDArray[indexPath.row])"
        // add border and color
        cell.backgroundColor = UIColor.white
        cell.layer.borderColor = UIColor.black.cgColor
        cell.layer.borderWidth = 1
        cell.layer.cornerRadius = 8
        cell.clipsToBounds = true
        return cell
    }
    
    func JSONCall()  {
        let urlstring = "https://api.letsbuildthatapp.com/jsondecodable/courses"
        guard let url = URL(string: urlstring) else{ return}
        URLSession.shared.dataTask(with:url) { (data, respon, erre) in
            guard let datastr = data else { return }
            do {
                let result =  try JSONDecoder().decode([info].self, from: datastr)
                for index in 0...result.count-1 {
                    let name = result[index].name
                    let  no = result[index].id
                    self.nameArray.append(name)
                    self.IDArray.append(no) }
                
                DispatchQueue.main.async() {
                    self.informationTable.reloadData()
                }
                
            } catch let jsonError {
                print("JSON Error",jsonError)}
            }.resume()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}

